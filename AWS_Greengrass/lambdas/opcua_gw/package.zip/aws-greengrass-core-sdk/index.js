/*
 * Copyright 2010-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */
exports.Lambda = require('./lambda');
exports.IotData = require('./iotdata');
